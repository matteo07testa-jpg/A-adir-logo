// Inspect pixels of the extracted frame
const fs = require('fs');
const path = require('path');

// Read PNG file - we use sharp (already installed via deps)
const sharp = require('sharp');

async function main() {
  const file = process.argv[2] || '/home/z/my-project/tests/fixtures/result-frame.png';
  const img = sharp(file);
  const meta = await img.metadata();
  console.log('Image size:', meta.width, 'x', meta.height);
  const { data, info } = await img.raw().toBuffer({ resolveWithObject: true });
  console.log('Raw buffer length:', data.length, 'channels:', info.channels);
  // Sample bottom-right area
  const w = info.width, h = info.height;
  function px(x, y) {
    const idx = (y * w + x) * info.channels;
    return [data[idx], data[idx+1], data[idx+2]];
  }
  // Check corners
  console.log('Top-left (0,0):', px(2, 2));
  console.log('Top-right (w-3,0):', px(w-3, 2));
  console.log('Bottom-left (0,h-3):', px(2, h-3));
  console.log('Bottom-right (w-3,h-3):', px(w-3, h-3));
  console.log('Center:', px(Math.floor(w/2), Math.floor(h/2)));
  // Logo is 15% wide = 96px, margin 4% = 25.6px
  // In bottom-right mode: logo spans x=[w-122, w-26], y=[h-122, h-26]
  // Sample center of that area
  const logoW = Math.round(0.15 * w);
  const m = Math.round(0.04 * w);
  const logoH = logoW;
  const centerX = Math.floor(w - m - logoW/2);
  const centerY = Math.floor(h - m - logoH/2);
  console.log('Logo area center:', centerX, centerY);
  console.log('Pixel at logo area center:', px(centerX, centerY));
  // Look for any magenta pixel anywhere
  let foundMagenta = 0;
  let firstMagenta = null;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const [r, g, b] = px(x, y);
      if (r > 200 && g < 100 && b > 200) {
        foundMagenta++;
        if (!firstMagenta) firstMagenta = { x, y };
        if (foundMagenta > 5) break;
      }
    }
    if (foundMagenta > 5) break;
  }
  console.log('Magenta pixels found:', foundMagenta, 'first:', firstMagenta);
}

main().catch(console.error);
