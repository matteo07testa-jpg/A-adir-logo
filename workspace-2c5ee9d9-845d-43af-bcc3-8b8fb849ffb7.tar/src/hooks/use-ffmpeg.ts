'use client'

import { useCallback, useRef, useState } from 'react'
import { FFmpeg } from '@ffmpeg/ffmpeg'
import { fetchFile, toBlobURL } from '@ffmpeg/util'

// ffmpeg.wasm needs core files (.wasm + .js worker glue). We load them from
// unpkg to avoid bundling them with Next.js. With COEP: require-corp, we need
// the response to be CORS-eligible AND we need to mark the request as
// credentialless (which toBlobURL does via fetch).
const CORE_BASE = 'https://unpkg.com/@ffmpeg/core@0.12.10/dist/umd'
// Use the single-threaded core for maximum browser compatibility.
// (Multi-threaded core requires even more headers + worker importScripts.)

type LoadState = 'idle' | 'loading' | 'ready' | 'error'

export function useFFmpeg() {
  const ffmpegRef = useRef<FFmpeg | null>(null)
  const [loadState, setLoadState] = useState<LoadState>('idle')
  const [loadError, setLoadError] = useState<string>('')

  const load = useCallback(async () => {
    if (ffmpegRef.current && loadState === 'ready') return ffmpegRef.current
    setLoadState('loading')
    setLoadError('')
    try {
      const ffmpeg = new FFmpeg()
      ffmpegRef.current = ffmpeg
      const coreURL = await toBlobURL(`${CORE_BASE}/ffmpeg-core.js`, 'text/javascript')
      const wasmURL = await toBlobURL(`${CORE_BASE}/ffmpeg-core.wasm`, 'application/wasm')
      await ffmpeg.load({ coreURL, wasmURL })
      setLoadState('ready')
      return ffmpeg
    } catch (e) {
      console.error('ffmpeg load error', e)
      setLoadError(e instanceof Error ? e.message : String(e))
      setLoadState('error')
      throw e
    }
  }, [loadState])

  // Check if SharedArrayBuffer is available (proxy for cross-origin isolation).
  // Compute once on first render — value cannot change without a full reload.
  const [isIsolated] = useState<boolean>(
    () => typeof crossOriginIsolated === 'boolean' ? crossOriginIsolated : false
  )

  return { load, loadState, loadError, isIsolated, ffmpegRef }
}
