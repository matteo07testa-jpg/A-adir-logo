'use client'

import { useRef, useState, useCallback } from 'react'
import { cn } from '@/lib/utils'

interface DropZoneProps {
  label: string
  accept: string
  file: File | null
  onFileSelected: (file: File) => void
  description?: string
  icon?: React.ReactNode
  previewUrl?: string | null
  previewType?: 'video' | 'image'
  extraInfo?: string
}

export function DropZone({
  label,
  accept,
  file,
  onFileSelected,
  description,
  icon,
  previewUrl,
  previewType,
  extraInfo,
}: DropZoneProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [isDragging, setIsDragging] = useState(false)

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      const dropped = e.dataTransfer.files
      if (dropped && dropped.length > 0) {
        onFileSelected(dropped[0])
      }
    },
    [onFileSelected]
  )

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  return (
    <div className="w-full">
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => inputRef.current?.click()}
        className={cn(
          'group relative cursor-pointer rounded-xl border-2 border-dashed transition-all',
          'px-6 py-10 flex flex-col items-center justify-center text-center',
          'min-h-[200px]',
          isDragging
            ? 'border-black bg-neutral-50 scale-[1.01]'
            : 'border-neutral-300 hover:border-neutral-500 hover:bg-neutral-50/50'
        )}
      >
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          className="sr-only"
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f) onFileSelected(f)
            e.target.value = ''
          }}
        />

        {previewUrl && file ? (
          <div className="w-full flex flex-col items-center gap-4">
            {previewType === 'video' ? (
              <video
                src={previewUrl}
                className="max-h-[180px] rounded-lg border border-neutral-200 bg-black"
                controls
                muted
              />
            ) : (
              <img
                src={previewUrl}
                alt={file.name}
                className="max-h-[160px] rounded-lg border border-neutral-200 bg-white object-contain p-2"
              />
            )}
            <div className="w-full">
              <p className="text-sm font-medium text-black truncate">{file.name}</p>
              {extraInfo && <p className="text-xs text-neutral-500 mt-0.5">{extraInfo}</p>}
            </div>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation()
                inputRef.current?.click()
              }}
              className="text-xs underline text-neutral-600 hover:text-black"
            >
              Cambiar archivo
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3 text-neutral-500">
            {icon && <div className="text-neutral-400 group-hover:text-neutral-600">{icon}</div>}
            <div>
              <p className="text-sm font-medium text-black">{label}</p>
              {description && (
                <p className="text-xs text-neutral-500 mt-1 max-w-xs">{description}</p>
              )}
            </div>
            <p className="text-[11px] text-neutral-400 mt-1">
              Arrastra aquí o haz clic para seleccionar
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
