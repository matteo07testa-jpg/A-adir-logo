// Read base64 from stdin, write to file
const { writeFileSync } = require('fs');
const b64 = require('fs').readFileSync('/dev/stdin', 'utf8').trim();
// Strip leading/trailing quotes if present
const clean = b64.replace(/^"|"$/g, '');
const buf = Buffer.from(clean, 'base64');
writeFileSync('/home/z/my-project/tests/fixtures/result-br.mp4', buf);
console.log('Saved', buf.length, 'bytes');
