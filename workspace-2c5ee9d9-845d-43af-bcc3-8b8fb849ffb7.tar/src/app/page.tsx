'use client'

import { useRef, useState, useCallback, useEffect } from 'react'
import { DropZone } from '@/components/DropZone'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/hooks/use-toast'
import { useFFmpeg } from '@/hooks/use-ffmpeg'
import { fetchFile } from '@ffmpeg/util'
import {
  Video,
  Image as ImageIcon,
  Download,
  Play,
  Loader2,
  RefreshCw,
  Settings2,
  AlertCircle,
  CornerDownLeft,
  CornerDownRight,
  Zap,
} from 'lucide-react'

type Status = 'idle' | 'ready' | 'processing' | 'done' | 'error'
type LogoPosition = 'bottom-left' | 'bottom-right'

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`
}

function formatTime(seconds: number) {
  if (!isFinite(seconds) || seconds < 0) seconds = 0
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}

export default function Home() {
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const [imageUrl, setImageUrl] = useState<string | null>(null)

  const [videoMeta, setVideoMeta] = useState<{ duration: number; width: number; height: number } | null>(null)
  const [imageMeta, setImageMeta] = useState<{ width: number; height: number } | null>(null)

  const [logoScale, setLogoScale] = useState<number>(15) // percentage of video width
  const [margin, setMargin] = useState<number>(4) // percentage margin from edges
  const [position, setPosition] = useState<LogoPosition>('bottom-left')

  const [status, setStatus] = useState<Status>('idle')
  const [progress, setProgress] = useState<number>(0)
  const [elapsedTime, setElapsedTime] = useState<number>(0)
  const [resultUrl, setResultUrl] = useState<string | null>(null)
  const [resultSize, setResultSize] = useState<number>(0)
  const [errorMsg, setErrorMsg] = useState<string>('')

  const videoRef = useRef<HTMLVideoElement | null>(null)
  const imageRef = useRef<HTMLImageElement | null>(null)
  const startTimeRef = useRef<number>(0)
  const progressHandlerRef = useRef<((r: number) => void) | null>(null)

  const { load: loadFFmpeg, loadState: ffmpegLoadState, loadError: ffmpegLoadError, isIsolated } = useFFmpeg()

  const { toast } = useToast()

  // Clean up object URLs
  useEffect(() => {
    const vUrl = videoUrl
    const iUrl = imageUrl
    const rUrl = resultUrl
    return () => {
      if (vUrl) URL.revokeObjectURL(vUrl)
      if (iUrl) URL.revokeObjectURL(iUrl)
      if (rUrl) URL.revokeObjectURL(rUrl)
    }
  }, [videoUrl, imageUrl, resultUrl])

  const handleVideoSelected = useCallback(
    (file: File) => {
      // Reset previous state
      if (videoUrl) URL.revokeObjectURL(videoUrl)
      if (resultUrl) {
        URL.revokeObjectURL(resultUrl)
        setResultUrl(null)
      }
      setStatus('idle')
      setProgress(0)
      setVideoMeta(null)
      setErrorMsg('')

      const url = URL.createObjectURL(file)
      setVideoFile(file)
      setVideoUrl(url)
    },
    [videoUrl, resultUrl]
  )

  const handleImageSelected = useCallback(
    (file: File) => {
      if (imageUrl) URL.revokeObjectURL(imageUrl)
      const url = URL.createObjectURL(file)
      setImageFile(file)
      setImageUrl(url)
      setImageMeta(null)

      const img = new Image()
      img.onload = () => {
        setImageMeta({ width: img.naturalWidth, height: img.naturalHeight })
      }
      img.src = url
    },
    [imageUrl]
  )

  // When video metadata loads, capture dims/duration
  const handleVideoLoadedMetadata = () => {
    const v = videoRef.current
    if (!v) return
    setVideoMeta({
      duration: v.duration,
      width: v.videoWidth,
      height: v.videoHeight,
    })
  }

  // Check if ready to process
  useEffect(() => {
    if (videoMeta && imageMeta && videoUrl && imageUrl) {
      setStatus('ready')
    } else {
      setStatus('idle')
    }
  }, [videoMeta, imageMeta, videoUrl, imageUrl])

  // Main processing function — uses ffmpeg.wasm for fast, offline, non-realtime processing
  const startProcessing = useCallback(async () => {
    if (!videoFile || !imageFile || !videoMeta) {
      setErrorMsg('Faltan datos. Asegúrate de subir un vídeo y un logo.')
      setStatus('error')
      return
    }

    // Reset previous result
    if (resultUrl) {
      URL.revokeObjectURL(resultUrl)
      setResultUrl(null)
    }
    setProgress(0)
    setElapsedTime(0)
    setErrorMsg('')
    setStatus('processing')
    startTimeRef.current = performance.now()

    // Pre-load ffmpeg in parallel with showing "processing" UI
    let ffmpeg
    try {
      ffmpeg = await loadFFmpeg()
    } catch {
      setErrorMsg(
        'No se pudo cargar el motor de procesamiento (ffmpeg.wasm). ' +
          (ffmpegLoadError || 'Revisa tu conexión a internet e inténtalo de nuevo.')
      )
      setStatus('error')
      return
    }

    // Attach progress listener
    const onProgress = (e: { progress: number }) => {
      const p = Math.max(0, Math.min(100, e.progress * 100))
      setProgress(p)
      setElapsedTime((performance.now() - startTimeRef.current) / 1000)
    }
    // The FFmpeg instance emits a 'progress' event
    ffmpeg.on('progress', onProgress)
    progressHandlerRef.current = onProgress

    try {
      // Compute target logo size and position in pixels
      if (!imageMeta) {
        setErrorMsg('No se pudo leer el logo. Inténtalo de nuevo.')
        setStatus('error')
        return
      }
      const vw = videoMeta.width
      const vh = videoMeta.height
      const logoWidth = Math.round((logoScale / 100) * vw)
      // Preserve aspect ratio for the logo's height
      const logoHeight = Math.round(
        (logoWidth * imageMeta.height) / imageMeta.width
      )
      const marginPx = Math.round((margin / 100) * vw)
      const logoX =
        position === 'bottom-right' ? vw - logoWidth - marginPx : marginPx
      const logoY = vh - logoHeight - marginPx

      // Write input files to ffmpeg's virtual FS
      const videoExt = videoFile.name.split('.').pop()?.toLowerCase() || 'mp4'
      const videoName = `input.${videoExt}`
      const logoExt = imageFile.name.split('.').pop()?.toLowerCase() || 'png'
      const logoName = `logo.${logoExt}`

      await ffmpeg.writeFile(videoName, await fetchFile(videoFile))
      await ffmpeg.writeFile(logoName, await fetchFile(imageFile))

      // Build the filtergraph:
      // - Scale the logo to target width while preserving aspect ratio.
      //   scale=W:-2 means "calculate height to preserve aspect, divisible by 2".
      // - Overlay at computed x,y.
      // Output as MP4 with H.264 + AAC. Use libx264 ultrafast preset for speed.
      const filterComplex =
        `[1:v]scale=${logoWidth}:-2[logo];` +
        `[0:v][logo]overlay=${logoX}:${logoY}[out]`

      const outName = 'output.mp4'

      await ffmpeg.exec([
        '-i',
        videoName,
        '-i',
        logoName,
        '-filter_complex',
        filterComplex,
        '-map',
        '[out]',
        '-map',
        '0:a?',
        '-c:v',
        'libx264',
        '-preset',
        'ultrafast',
        '-crf',
        '23',
        '-c:a',
        'aac',
        '-b:a',
        '128k',
        '-movflags',
        '+faststart',
        '-y',
        outName,
      ])

      // Read output and create a blob URL
      const data = (await ffmpeg.readFile(outName)) as Uint8Array
      const blob = new Blob([data.buffer as ArrayBuffer], { type: 'video/mp4' })
      const url = URL.createObjectURL(blob)
      setResultUrl(url)
      setResultSize(blob.size)
      setProgress(100)
      setStatus('done')
      toast({
        title: 'Vídeo procesado',
        description: 'Tu vídeo con el logo está listo para descargar.',
      })

      // Cleanup virtual FS
      try {
        await ffmpeg.deleteFile(videoName)
        await ffmpeg.deleteFile(logoName)
        await ffmpeg.deleteFile(outName)
      } catch {
        // ignore cleanup errors
      }
    } catch (e) {
      console.error('ffmpeg processing error', e)
      setErrorMsg(
        'Error al procesar el vídeo. Puede que el formato no sea compatible. ' +
          'Prueba con un MP4 o MOV.'
      )
      setStatus('error')
    } finally {
      try {
        ffmpeg?.off('progress', onProgress)
      } catch {
        // ignore
      }
      progressHandlerRef.current = null
    }
  }, [videoFile, imageFile, videoMeta, imageMeta, logoScale, margin, position, resultUrl, toast, loadFFmpeg, ffmpegLoadError])

  const stopProcessing = useCallback(() => {
    // ffmpeg.wasm doesn't support graceful mid-execution cancellation in 0.12.x.
    // The user can refresh the page if they need to abort.
    // We show a notification that this is the case.
    toast({
      title: 'No se puede cancelar',
      description: 'El procesamiento de ffmpeg no se puede detener a mitad. Refresca la página si necesitas abortar.',
    })
  }, [toast])

  const reset = useCallback(() => {
    if (resultUrl) {
      URL.revokeObjectURL(resultUrl)
      setResultUrl(null)
    }
    setProgress(0)
    setElapsedTime(0)
    setStatus(videoMeta && imageMeta ? 'ready' : 'idle')
    setErrorMsg('')
  }, [stopProcessing, resultUrl, videoMeta, imageMeta])

  const canProcess = status === 'ready' && videoMeta && imageMeta

  return (
    <div className="min-h-screen flex flex-col bg-white text-black">
      {/* Header */}
      <header className="border-b border-neutral-200">
        <div className="max-w-5xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-black flex items-center justify-center">
              <Video className="w-4 h-4 text-white" strokeWidth={2.2} />
            </div>
            <span className="font-semibold tracking-tight">Logo Overlay</span>
          </div>
          <div className="text-xs text-neutral-500 hidden sm:block">
            Procesamiento local · Tu vídeo no se sube a ningún servidor
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-6 py-10 md:py-14">
        {/* Hero */}
        <section className="mb-10 md:mb-14">
          <h1 className="text-3xl md:text-5xl font-semibold tracking-tight leading-[1.1]">
            Pon tu logo en tu vídeo.
            <br />
            <span className="text-neutral-400">Simple y rápido.</span>
          </h1>
          <p className="mt-4 text-base md:text-lg text-neutral-600 max-w-2xl leading-relaxed">
            Sube un vídeo (hasta 30 minutos) y un logo. La herramienta colocará
            tu logo en la esquina inferior izquierda o derecha, durante todo el
            vídeo. Procesamiento acelerado con ffmpeg.wasm — 5–15× más rápido
            que en tiempo real. Todo ocurre en tu navegador.
          </p>
        </section>

        {/* Upload section */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-8">
          <DropZone
            label="Sube tu vídeo"
            description="MP4, MOV, WebM, MKV · hasta 30 minutos"
            accept="video/*"
            file={videoFile}
            onFileSelected={handleVideoSelected}
            previewUrl={videoUrl}
            previewType="video"
            icon={<Video className="w-7 h-7" strokeWidth={1.5} />}
            extraInfo={
              videoMeta
                ? `${videoMeta.width}×${videoMeta.height} · ${formatTime(videoMeta.duration)} min`
                : undefined
            }
          />
          <DropZone
            label="Sube tu logo"
            description="PNG (con transparencia recomendado), JPG, WebP"
            accept="image/*"
            file={imageFile}
            onFileSelected={handleImageSelected}
            previewUrl={imageUrl}
            previewType="image"
            icon={<ImageIcon className="w-7 h-7" strokeWidth={1.5} />}
            extraInfo={
              imageMeta ? `${imageMeta.width}×${imageMeta.height} px` : undefined
            }
          />
        </section>

        {/* Hidden elements for processing */}
        <video
          ref={videoRef}
          src={videoUrl ?? undefined}
          onLoadedMetadata={handleVideoLoadedMetadata}
          className="hidden"
          playsInline
          preload="auto"
          muted
        />
        {imageUrl && (
          <img
            ref={imageRef}
            src={imageUrl}
            alt="logo"
            className="hidden"
            onLoad={(e) => {
              const img = e.currentTarget
              setImageMeta({ width: img.naturalWidth, height: img.naturalHeight })
            }}
          />
        )}

        {/* Settings */}
        {canProcess && (
          <section className="mb-8 border border-neutral-200 rounded-xl p-6">
            <div className="flex items-center gap-2 mb-5">
              <Settings2 className="w-4 h-4 text-neutral-500" />
              <h2 className="text-sm font-medium">Ajustes del logo</h2>
            </div>

            {/* Position selector */}
            <div className="mb-8">
              <label className="text-sm text-neutral-700 block mb-2">Posición</label>
              <div className="inline-flex rounded-lg border border-neutral-200 bg-neutral-50 p-1">
                <button
                  type="button"
                  onClick={() => setPosition('bottom-left')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    position === 'bottom-left'
                      ? 'bg-black text-white shadow-sm'
                      : 'text-neutral-600 hover:text-black'
                  }`}
                  aria-pressed={position === 'bottom-left'}
                >
                  <CornerDownLeft className="w-4 h-4" />
                  Abajo izquierda
                </button>
                <button
                  type="button"
                  onClick={() => setPosition('bottom-right')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    position === 'bottom-right'
                      ? 'bg-black text-white shadow-sm'
                      : 'text-neutral-600 hover:text-black'
                  }`}
                  aria-pressed={position === 'bottom-right'}
                >
                  <CornerDownRight className="w-4 h-4" />
                  Abajo derecha
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <div className="flex justify-between items-baseline mb-2">
                  <label className="text-sm text-neutral-700">Tamaño</label>
                  <span className="text-xs font-mono text-neutral-500">
                    {logoScale}% del ancho
                  </span>
                </div>
                <Slider
                  value={[logoScale]}
                  onValueChange={(v) => setLogoScale(v[0])}
                  min={5}
                  max={35}
                  step={1}
                />
                <p className="text-xs text-neutral-400 mt-1.5">
                  Recomendado: 10–20%
                </p>
              </div>

              <div>
                <div className="flex justify-between items-baseline mb-2">
                  <label className="text-sm text-neutral-700">Margen del borde</label>
                  <span className="text-xs font-mono text-neutral-500">
                    {margin}% del ancho
                  </span>
                </div>
                <Slider
                  value={[margin]}
                  onValueChange={(v) => setMargin(v[0])}
                  min={1}
                  max={15}
                  step={1}
                />
                <p className="text-xs text-neutral-400 mt-1.5">
                  Distancia desde los bordes inferior y lateral
                </p>
              </div>
            </div>

            {/* Preview thumbnail */}
            <div className="mt-6">
              <p className="text-xs text-neutral-500 mb-2">Vista previa</p>
              <PreviewCanvas
                videoRef={videoRef}
                imageRef={imageRef}
                videoMeta={videoMeta}
                imageMeta={imageMeta}
                logoScale={logoScale}
                margin={margin}
                position={position}
              />
            </div>
          </section>
        )}

        {/* Action button */}
        {canProcess && status === 'ready' && (
          <section className="mb-8 flex justify-center">
            <Button
              onClick={startProcessing}
              size="lg"
              className="bg-black text-white hover:bg-neutral-800 rounded-full px-8 h-12 text-base font-medium"
            >
              <Play className="w-4 h-4 mr-2" />
              Procesar vídeo
            </Button>
          </section>
        )}

        {/* Processing status */}
        {status === 'processing' && (
          <section className="mb-8 border border-neutral-200 rounded-xl p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {ffmpegLoadState === 'loading' || progress < 1 ? (
                  <Loader2 className="w-4 h-4 animate-spin text-neutral-500" />
                ) : (
                  <Zap className="w-4 h-4 text-neutral-500" />
                )}
                <span className="text-sm font-medium">
                  {ffmpegLoadState === 'loading'
                    ? 'Cargando motor de procesamiento…'
                    : progress < 1
                      ? 'Preparando…'
                      : 'Procesando…'}
                </span>
              </div>
            </div>
            <Progress value={progress} className="h-2 bg-neutral-100" />
            <div className="flex justify-between mt-3 text-xs text-neutral-500 font-mono">
              <span>{progress.toFixed(1)}%</span>
              <span>Tiempo: {formatTime(elapsedTime)}</span>
            </div>
            <p className="text-xs text-neutral-400 mt-3">
              {ffmpegLoadState === 'loading'
                ? 'La primera vez se descarga el motor ffmpeg (~30MB). Se cachea para próximas sesiones.'
                : 'Procesamiento acelerado con ffmpeg.wasm. Un vídeo de 30 min tarda 2–5 min aproximadamente.'}
            </p>
          </section>
        )}

        {/* Error */}
        {status === 'error' && (
          <section className="mb-8 border border-red-200 bg-red-50 rounded-xl p-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-red-900">Algo salió mal</p>
                <p className="text-sm text-red-700 mt-1">{errorMsg}</p>
                <Button
                  onClick={reset}
                  variant="outline"
                  size="sm"
                  className="mt-3 rounded-full"
                >
                  <RefreshCw className="w-3 h-3 mr-1.5" />
                  Intentar de nuevo
                </Button>
              </div>
            </div>
          </section>
        )}

        {/* Result */}
        {status === 'done' && resultUrl && (
          <section className="mb-8 border border-neutral-200 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-medium">Tu vídeo está listo</h2>
              <button
                onClick={reset}
                className="text-xs text-neutral-500 hover:text-black underline"
              >
                Procesar otro
              </button>
            </div>
            <video
              src={resultUrl}
              controls
              className="w-full rounded-lg border border-neutral-200 bg-black max-h-[500px]"
            />
            <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <p className="text-xs text-neutral-500">
                Tamaño: {formatBytes(resultSize)} · Formato: MP4 (H.264 + AAC)
              </p>
              <a href={resultUrl} download={`video-con-logo-${Date.now()}.mp4`}>
                <Button className="bg-black text-white hover:bg-neutral-800 rounded-full px-6">
                  <Download className="w-4 h-4 mr-2" />
                  Descargar vídeo
                </Button>
              </a>
            </div>
          </section>
        )}

        {/* Footer note */}
        <section className="mt-16 pt-8 border-t border-neutral-100">
          <p className="text-xs text-neutral-400 leading-relaxed max-w-2xl">
            <strong className="text-neutral-600">Nota:</strong> El procesamiento
            ocurre enteramente en tu navegador usando ffmpeg.wasm. La primera
            vez se descarga el motor (~30MB); después se cachea y va mucho más
            rápido. La salida está en formato MP4 (H.264 + AAC), compatible con
            cualquier reproductor. Para vídeos muy largos o de gran resolución,
            asegúrate de tener suficiente memoria disponible.
          </p>
          {isIsolated === false && (
            <p className="text-xs text-amber-600 mt-2 leading-relaxed">
              <strong>Aviso:</strong> Tu navegador no está aislado cross-origin.
              El procesamiento funcionará, pero más lento (sin hilos
              paralelos). Si despliegas esta app, asegúrate de configurar los
              headers COOP/COEP.
            </p>
          )}
        </section>
      </main>
    </div>
  )
}

// Inline preview component that renders a frame from the parent's loaded video
// with the logo overlaid at the configured position. Uses the parent's
// videoRef directly (already loaded with metadata) to avoid reloading issues.
function PreviewCanvas({
  videoRef,
  imageRef,
  videoMeta,
  imageMeta,
  logoScale,
  margin,
  position,
}: {
  videoRef: React.RefObject<HTMLVideoElement | null>
  imageRef: React.RefObject<HTMLImageElement | null>
  videoMeta: { duration: number; width: number; height: number } | null
  imageMeta: { width: number; height: number } | null
  logoScale: number
  margin: number
  position: LogoPosition
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const video = videoRef.current
    const logo = imageRef.current
    const canvas = canvasRef.current
    if (!video || !logo || !canvas || !videoMeta || !imageMeta) return

    // Make sure the video has enough data to draw
    if (video.readyState < 2) {
      // Wait for data
      const onReady = () => drawPreview()
      video.addEventListener('loadeddata', onReady, { once: true })
      return () => video.removeEventListener('loadeddata', onReady)
    }

    function drawPreview() {
      const v = videoRef.current
      const lg = imageRef.current
      const cv = canvasRef.current
      if (!v || !lg || !cv || !videoMeta) return

      const ctx = cv.getContext('2d', { alpha: false })
      if (!ctx) return

      // Cap preview canvas at 1280 wide for performance
      const maxW = 1280
      const scale = videoMeta.width > maxW ? maxW / videoMeta.width : 1
      cv.width = Math.round(videoMeta.width * scale)
      cv.height = Math.round(videoMeta.height * scale)

      // Draw current video frame
      try {
        ctx.drawImage(v, 0, 0, cv.width, cv.height)
      } catch {
        // Video not yet ready to draw — try once more after a short delay
        setTimeout(() => drawPreview(), 200)
        return
      }

      // Draw logo at the configured corner
      const lw = (logoScale / 100) * cv.width
      const lh = lw * (lg.naturalHeight / lg.naturalWidth)
      const m = (margin / 100) * cv.width
      const x = position === 'bottom-right' ? cv.width - lw - m : m
      const y = cv.height - lh - m
      ctx.drawImage(lg, x, y, lw, lh)
    }

    drawPreview()
  }, [videoRef, imageRef, videoMeta, imageMeta, logoScale, margin, position])

  return (
    <canvas
      ref={canvasRef}
      className="w-full max-h-[360px] rounded-lg border border-neutral-200 bg-black object-contain"
    />
  )
}
